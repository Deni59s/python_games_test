### Hexlet tests and linter status:
[![Actions Status](https://github.com/Deni59s/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Deni59s/python-project-49/actions)
<a href="https://codeclimate.com/github/Deni59s/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/56eb948bb900c93fde79/maintainability" /></a>
## Игра "Четное / нечетное число"
<a href="https://asciinema.org/a/3S0wHnzg9bV6XtyjNaAI4Srih" target="_blank"><img src="https://asciinema.org/a/3S0wHnzg9bV6XtyjNaAI4Srih.svg" /></a>
## Игра "Калькулятор"
<a href="https://asciinema.org/a/RXPQt032qVPRwlR1U3odtEReh" target="_blank"><img src="https://asciinema.org/a/RXPQt032qVPRwlR1U3odtEReh.svg" /></a>
## Игра "Нахождение НОД"
<a href="https://asciinema.org/a/ea9qO0Onq7DpNrRoFFdfLqRUW" target="_blank"><img src="https://asciinema.org/a/ea9qO0Onq7DpNrRoFFdfLqRUW.svg" /></a>
## Игра "Арифметическая прогрессия"
<a href="https://asciinema.org/a/LwAJx2LElNcQ3i9UsYEgYc3GU" target="_blank"><img src="https://asciinema.org/a/LwAJx2LElNcQ3i9UsYEgYc3GU.svg" /></a>