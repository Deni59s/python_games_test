### Hexlet tests and linter status:
[![Actions Status](https://github.com/Deni59s/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Deni59s/python-project-49/actions)
<a href="https://codeclimate.com/github/Deni59s/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/56eb948bb900c93fde79/maintainability" /></a>
<a href="https://asciinema.org/a/J8l2QAJ7t96omoQyGOdWxqV4x" target="_blank"><img src="https://asciinema.org/a/J8l2QAJ7t96omoQyGOdWxqV4x.svg" /></a>