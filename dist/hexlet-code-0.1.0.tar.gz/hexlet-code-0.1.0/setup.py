# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'Brain games',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/Deni59s/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Deni59s/python-project-49/actions)\n<a href="https://codeclimate.com/github/Deni59s/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/56eb948bb900c93fde79/maintainability" /></a>\n## Игра "Четное / нечетное число"\n<a href="https://asciinema.org/a/3S0wHnzg9bV6XtyjNaAI4Srih" target="_blank"><img src="https://asciinema.org/a/3S0wHnzg9bV6XtyjNaAI4Srih.svg" /></a>\n## Игра "Калькулятор"\n<a href="https://asciinema.org/a/RXPQt032qVPRwlR1U3odtEReh" target="_blank"><img src="https://asciinema.org/a/RXPQt032qVPRwlR1U3odtEReh.svg" /></a>\n## Игра "Нахождение НОД"\n<a href="https://asciinema.org/a/ea9qO0Onq7DpNrRoFFdfLqRUW" target="_blank"><img src="https://asciinema.org/a/ea9qO0Onq7DpNrRoFFdfLqRUW.svg" /></a>\n## Игра "Арифметическая прогрессия"\n<a href="https://asciinema.org/a/LwAJx2LElNcQ3i9UsYEgYc3GU" target="_blank"><img src="https://asciinema.org/a/LwAJx2LElNcQ3i9UsYEgYc3GU.svg" /></a>\n## Игра "Простое-ли число?"\n<a href="https://asciinema.org/a/xT2WoGM6QWlbwvyZ4HmxOpiYH" target="_blank"><img src="https://asciinema.org/a/xT2WoGM6QWlbwvyZ4HmxOpiYH.svg" /></a>',
    'author': 'Denis',
    'author_email': 'dannychetverikov@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/Deni59s/python-project-49',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
