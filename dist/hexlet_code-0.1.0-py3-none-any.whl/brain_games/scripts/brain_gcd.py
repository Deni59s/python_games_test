from brain_games.welcome_home import welcome_name
from brain_games.games import game_gcd


def main():
    welcome_name(game_gcd)  # вызов ф-ии с запросом имени из дир-ии brain_games/


if __name__ == '__main__':
    main()
